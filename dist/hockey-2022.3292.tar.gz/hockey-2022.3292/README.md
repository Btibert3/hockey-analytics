# About


A personal toolkit to help with all things analyzing hockey data


## Use cases

- utilities to help with NHL PBP event data
- plotting
- data cleaning
- modeling
- general nerdery


