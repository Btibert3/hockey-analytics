"""A python package to facilitate working with hockey data."""

# change to calendar versioning of sorts 
# YYYY.MMDDv where v is 1 based within the month/day combo
# TODO:  follow best practices here
__version__ = '2022.03292'

from .viz import *
